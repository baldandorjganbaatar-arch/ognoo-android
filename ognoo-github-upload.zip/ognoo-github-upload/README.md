# Ognoo Android APK build

This repository builds a debug APK with GitHub Actions.

## GitHub upload

1. Extract the ZIP file on your computer.
2. In your `ognoo-android` GitHub repository, choose **Add file → Upload files**.
3. Upload the extracted contents, keeping the folder structure (especially `.github/workflows/build-apk.yml`).
4. Commit to the `main` branch.
5. Open the **Actions** tab and select **Build Ognoo Android APK**.
6. When the run finishes successfully, open the run and download **ognoo-android-apk** under Artifacts. Extract it to get `app-debug.apk`.

The APK is an unsigned debug build intended for direct testing/installing, not Play Store publication.

## App details

- App name: Ognoo
- Android application ID: `mn.ognoo.app`
- Web app source: `www/index.html`

Note: this package wraps the current Ognoo V2 HTML app. Its current reminder logic runs while the app is open; reliable daily notifications while the app is closed still need native Android local-notification scheduling to be added and tested.
